apt install git -y
git clone https://github.com/ShinobiCCTV/Shinobi.git -b dev Shinobi-dev
cd Shinobi-dev
chmod +x INSTALL/ubuntu-easyinstall.sh && INSTALL/ubuntu-easyinstall.sh
bash INSTALL/ubuntu-easyinstall.sh